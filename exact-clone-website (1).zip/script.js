const screens=["passcode","countdown","build","custom","favorites"];
const slots=[...document.querySelectorAll("#codeSlots span")];
let code="";
const correct="1234";

function show(name){
  screens.forEach(id=>document.getElementById(id).classList.toggle("hidden",id!==name));
}
document.querySelectorAll("#keypad button").forEach(btn=>{
  btn.addEventListener("click",()=>{
    if(code.length>=4)return;
    code+=btn.dataset.key;
    slots.forEach((s,i)=>s.textContent=code[i]?"♥":"");
  });
});
function unlock(){
  if(code===correct){
    show("countdown");
    let n=5;
    const img=document.querySelector("#countdown img");
    // Keep the supplied visual reference, then continue through the same sequence.
    setTimeout(()=>show("build"),2700);
  }else{
    code="";
    slots.forEach(s=>s.textContent="");
    document.querySelector(".pass-right").animate(
      [{transform:"translateX(-8px)"},{transform:"translateX(8px)"},{transform:"translateX(0)"}],
      {duration:260}
    );
  }
}
document.getElementById("unlock").addEventListener("click",unlock);
document.querySelector(".next").addEventListener("click",()=>show("custom"));
document.querySelector(".arrow").addEventListener("click",()=>show("favorites"));
document.querySelectorAll(".back").forEach(b=>b.addEventListener("click",()=>{
  const current=screens.find(id=>!document.getElementById(id).classList.contains("hidden"));
  if(current==="build")show("passcode");
  if(current==="custom")show("build");
  if(current==="favorites")show("custom");
}));
document.querySelector(".envelope").addEventListener("click",()=>select("envelope"));
document.querySelector(".bouquet").addEventListener("click",()=>select("bouquet"));
document.querySelector(".gift").addEventListener("click",()=>select("gift"));
function select(type){
  const note=document.getElementById("selection");
  note.textContent=type==="envelope"?"Love letter selected ♥":type==="bouquet"?"Bouquet selected ✿":"Gift selected 🎁";
  note.style.opacity=1;
}
show("passcode");
