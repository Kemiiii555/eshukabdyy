# Exact visual clone from the supplied screen recording

This is a lightweight HTML/CSS/JavaScript recreation of the recorded interaction.

## Run
Open `index.html` directly, or serve the folder with any static server.

Example:
```bash
python -m http.server 3000
```
Then open http://localhost:3000

## Flow
1. Passcode screen — `1234`
2. Countdown screen
3. Build Your Bouquet
4. Custom bouquet display
5. Pick Your Favorites

The screenshot assets are taken from the supplied recording to preserve the recorded visual appearance.
